﻿// Release configuration
// Do not use the original (deleted that line), use the following one (OguzP)
var baseAddress = 'http://' + window.location.hostname + ':8080'