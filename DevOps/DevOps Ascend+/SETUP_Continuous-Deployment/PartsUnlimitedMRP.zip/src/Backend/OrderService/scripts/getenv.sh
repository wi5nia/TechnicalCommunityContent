#!/bin/sh
echo ""
echo "Getting the environment"
echo ""

env