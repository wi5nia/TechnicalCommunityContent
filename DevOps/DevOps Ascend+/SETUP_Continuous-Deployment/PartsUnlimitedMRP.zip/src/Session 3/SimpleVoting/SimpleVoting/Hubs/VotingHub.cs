﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace SimpleVoting.Hubs
{
    public class VotingHub : Hub
    {
        private static Question _CurrentQuestion = null;
        private static Dictionary<string, int> _UserVotes = new Dictionary<string, int>();

        public void RequestQuestionDetails()
        {
            Clients.Caller.onQuestionUpdate(_CurrentQuestion);
        }

        public void Vote(Vote Vote)
        {
            if (_CurrentQuestion != null)
            {
                if (_CurrentQuestion.Results == null)
                {
                    _CurrentQuestion.Results = new VotingResults()
                    {
                        Results = new int[_CurrentQuestion.Details.Options.Length],
                    };
                    var User = Context.ConnectionId;
                }
                var Id = Context.ConnectionId;
                bool UpdateUsers = false;

                int PreviousVote;
                if (_UserVotes.TryGetValue(Id, out PreviousVote))
                {
                    if (PreviousVote != Vote.ChoiceIndex)
                    {
                        _CurrentQuestion.Results.Results[PreviousVote]--;
                        UpdateUsers = true;
                    }
                }
                else
                    UpdateUsers = true;

                if(UpdateUsers)
                {
                    _UserVotes[Id] = Vote.ChoiceIndex;
                    _CurrentQuestion.Results.Results[Vote.ChoiceIndex]++;
                    OnNewVote(Vote);
                }
            }
        }

        public void ClearQuestion()
        {
            _CurrentQuestion = null;
            _UserVotes.Clear();
            OnNewQuestion();
        }

        public void SetNewQuestion(NewQuestionRequest Request)
        {            
            var Passcode = System.Web.Configuration.WebConfigurationManager.AppSettings["PassCode"];

            if ((Request?.Passcode ?? "").Equals(Passcode) == false)
                return;

            _UserVotes.Clear();
            _CurrentQuestion = new Question()
            {
                Details = Request.Details,
            };
            OnNewQuestion();
        }

        private void OnNewQuestion()
        {
            Clients.All.onQuestionUpdate(_CurrentQuestion);
        }

        private void OnNewVote(Vote Vote)
        {
            Clients.All.onResultsUpdate(_CurrentQuestion?.Results);
        }
    }
}