﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SimpleVoting.Hubs
{
    public class Question
    {
        public QuestionDetails Details { get; set; }
        public VotingResults Results { get; set; }
    }
    public class QuestionDetails
    {
        public string Question { get; set; }
        public string[] Options { get; set; }
    }
    public class VotingResults
    {
        public int[] Results { get; set; }
    }
    public class NewQuestionRequest
    {
        public QuestionDetails Details { get; set; }
        public string Passcode { get; set; }
    }
    public class Vote
    {
        public int ChoiceIndex { get; set; }
    }
}