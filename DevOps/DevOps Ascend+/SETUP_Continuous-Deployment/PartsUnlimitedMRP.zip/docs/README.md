# Learning Path

You may use following order for walking through the labs:

0. [Sessions](./Sessions/README.md)

0. [Application Performance Monitoring](https://github.com/Microsoft/PartsUnlimitedMRP/tree/master/docs/HOL_Application-Performance-Monitoring)

There are also 2 labs that walk through the steps to deploy the MRP application using Chef and Puppet :

- [Parts Unlimited MRP - Continuous Deployment with Chef (ext)](https://microsoft.github.io/PartsUnlimitedMRP/fundoth/fund-14-Oth-chef.html)
- [Parts Unlimited MRP - Continuous Deployment with Puppet (ext)](https://microsoft.github.io/PartsUnlimitedMRP/fundoth/fund-13-Oth-puppet.html)
