﻿param(
  [string]
  $InstrumentationKey
)

if(-not $InstrumentationKey) {
  exit 0
}

$ErrorActionPreference = 'Stop'
$currentDir = Split-Path $script:MyInvocation.MyCommand.Path

# Application Insights html code snippet that is injected in Clients web app pages.
$instrumentationCode = @"

    <!-- Application Insights

    To collect end-user usage analytics about your application,
    insert the following script into each page you want to track.
    Place this code immediately before the closing </head> tag,
    and before any other scripts. Your first data will appear
    automatically in just a few seconds.

    -->
    <script type="text/javascript">
        var appInsights=window.appInsights||function(config){
            function i(config){t[config]=function(){var i=arguments;t.queue.push(function(){t[config].apply(t,i)})}}var t={config:config},u=document,e=window,o="script",s="AuthenticatedUserContext",h="start",c="stop",l="Track",a=l+"Event",v=l+"Page",y=u.createElement(o),r,f;y.src=config.url||"https://az416426.vo.msecnd.net/scripts/a/ai.0.js";u.getElementsByTagName(o)[0].parentNode.appendChild(y);try{t.cookie=u.cookie}catch(p){}for(t.queue=[],t.version="1.0",r=["Event","Exception","Metric","PageView","Trace","Dependency"];r.length;)i("track"+r.pop());return i("set"+s),i("clear"+s),i(h+a),i(c+a),i(h+v),i(c+v),i("flush"),config.disableExceptionTracking||(r="onerror",i("_"+r),f=e[r],e[r]=function(config,i,u,e,o){var s=f&&f(config,i,u,e,o);return s!==!0&&t["_"+r](config,i,u,e,o),s}),t
        }({
            instrumentationKey:"$InstrumentationKey"
        });
        
        window.appInsights=appInsights;
        appInsights.trackPageView();
    </script>
"@

$instrumentationCode

# Get the BUILD_DEFINITIONNAME environment variable set by the build agent at runtime
$buildName = $($env:BUILD_DEFINITIONNAME)
if(-not $buildName) { $buildName = 'PartsUnlimitedMRPCI' }
$buildName = $buildName.Replace(".","")

# Define a temporary working directory location
$working_dir = Join-Path ([System.IO.Path]::GetTempPath()) APM
# If temporary working exist, delete it
if(Test-Path $working_dir) {
  Remove-Item -Path $working_dir -Recurse -Force
}
# Create working directory
$null = New-item -Path $working_dir -ItemType Directory -Force

###
# Order
###
# Search for ordering service archive file from artifacts
$orderArchive = Get-Item ./$buildName/drop/Backend/OrderService/build/libs/ordering-service*.jar
# Create a directory for Order manipulation under the working directory
$orderWorkingDirectory = Join-Path $working_dir order
$null = New-Item -Path $orderWorkingDirectory -ItemType Directory
# Extract the order archive
& $currentDir\7z.exe x $orderArchive "-o$($orderWorkingDirectory)" * -r

# Inject instrumentation key into ApplicationInsights.xml
[xml]$configFile = Get-Content -Path $orderWorkingDirectory\ApplicationInsights.xml -Raw
$configFile.ApplicationInsights.InstrumentationKey = $InstrumentationKey
$configFile.Save("$orderWorkingDirectory\ApplicationInsights.xml")

# Update the order archive with updated file
& $currentDir\7z.exe u $orderArchive $orderWorkingDirectory\*.*


###
# Clients
###
# Search for clients archive file from artifacts
$clientsArchive = Get-Item  ./$buildName/drop/Clients/build/libs/mrp*.war
# Create a directory for Clients manipulation under the working directory
$clientsWorkingDirectory = Join-Path $working_dir mrp
$null = New-Item -Path $clientsWorkingDirectory -ItemType Directory
# Extract the clients archive
& $currentDir\7z.exe x $clientsArchive "-o$($clientsWorkingDirectory)" * -r

# Inject AppInsights code snippet into Clients web app pages
@(
  'index.html'
  'pages/catalog/catalog.html'
  'pages/dealers/dealers.html'
  'pages/deliveries/deliveries.html'
  'pages/orders/orders.html'
  'pages/quotes/quotes.html'
) | % {
  Write-Output "Processing $_"
  $page = Get-Item -Path $clientsWorkingDirectory\$_
  $html = Get-Content -Path $page -Raw
  $html = $html -replace '</title>', "</title>$instrumentationCode"
  Set-Content -Path $page -Value $html -Encoding UTF8 -Force  
}

# Update the clients archive with updated files
& $currentDir\7z.exe u $clientsArchive $clientsWorkingDirectory\*.* -r

# Remove temporary working directory
Remove-Item -Path $working_dir -Recurse -Force